#!/usr/bin/env python3
"""Build the harness-side audit record for one Forge run.

Runs after the agent's container has exited, in a separate container with no network,
reading only what the host captured. The agent cannot edit any of its inputs or outputs.

Reads:   <run_dir>/transcript.jsonl  (one {"ts": ..., "event": <claude stream-json event>} per line)
         <run_dir>/stderr.log, <run_dir>/code/
Writes:  <run_dir>/audit.md, <run_dir>/files_manifest.txt, <run_dir>/meta.json

Usage: make_audit.py <run_dir> <container_exit_code> <interrupted 0|1> <run_info.json>
"""
import hashlib
import json
import os
import re
import sys

MAX_TEXT = 3000      # max chars of agent text per entry in audit.md
MAX_OUTPUT = 1200    # max chars of command output per entry in audit.md


def load_events(path):
    events = []
    if not os.path.exists(path):
        return events
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                events.append({"ts": "?", "event": {"type": "unparsed", "raw": line[:500]}})
                continue
            if "event" not in rec:  # tolerate raw (untimestamped) stream-json lines
                rec = {"ts": "?", "event": rec}
            events.append(rec)
    return events


def clip(s, n):
    s = s if isinstance(s, str) else json.dumps(s, ensure_ascii=False)
    return s if len(s) <= n else s[:n] + f"\n... [{len(s) - n} more chars, see transcript.jsonl]"


def result_text(content):
    """Flatten a tool_result's content (string or list of blocks) to text."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict) and b.get("type") == "text":
                parts.append(b.get("text", ""))
            elif isinstance(b, dict):
                parts.append(f"[{b.get('type', 'block')}]")
        return "\n".join(parts)
    return json.dumps(content, ensure_ascii=False)


def describe_tool(name, inp):
    if not isinstance(inp, dict):
        return f"**{name}**"
    if name == "Bash":
        return f"**Bash**\n```bash\n{clip(inp.get('command', ''), MAX_TEXT)}\n```"
    if name == "Write":
        content = inp.get("content", "")
        return f"**Write** `{inp.get('file_path')}` ({len(content)} chars)"
    if name in ("Edit", "MultiEdit"):
        return f"**{name}** `{inp.get('file_path')}`"
    if name == "Read":
        return f"**Read** `{inp.get('file_path')}`"
    if name in ("Glob", "Grep"):
        return f"**{name}** `{inp.get('pattern')}`" + (f" in `{inp['path']}`" if inp.get("path") else "")
    return f"**{name}** `{clip(inp, 300)}`"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def number_variants(x):
    """String forms a printed metric might take."""
    out = {repr(x), str(x)}
    for d in range(2, 8):
        out.add(f"{x:.{d}f}")
    out.add(f"{x:.4g}")
    out.add(f"{x:.6g}")
    return {v for v in out if len(v.replace("-", "").replace(".", "").lstrip("0")) >= 2}


def main():
    run_dir, container_rc, interrupted, info_path = sys.argv[1], int(sys.argv[2]), sys.argv[3] == "1", sys.argv[4]
    with open(info_path) as f:
        info = json.load(f)

    events = load_events(os.path.join(run_dir, "transcript.jsonl"))
    code_dir = os.path.join(run_dir, "code")
    stderr_path = os.path.join(run_dir, "stderr.log")
    stderr = open(stderr_path, errors="replace").read() if os.path.exists(stderr_path) else ""
    firewall_ok = "firewall: OK" in stderr

    # ---- walk the transcript ----
    tool_names = {}
    entries = []
    all_output = []          # every tool result text, for the results cross-check
    final = None
    n_tool_calls = 0
    n_errors = 0
    for rec in events:
        ts, ev = rec.get("ts", "?"), rec.get("event", {})
        et = ev.get("type")
        if et == "system" and ev.get("subtype") == "init":
            entries.append(f"### [{ts}] SESSION START\nmodel: `{ev.get('model')}`, tools: {', '.join(ev.get('tools', []))}")
        elif et == "assistant":
            for block in ev.get("message", {}).get("content", []):
                if block.get("type") == "text" and block.get("text", "").strip():
                    entries.append(f"### [{ts}] AGENT\n{clip(block['text'].strip(), MAX_TEXT)}")
                elif block.get("type") == "tool_use":
                    n_tool_calls += 1
                    tool_names[block.get("id")] = block.get("name")
                    entries.append(f"### [{ts}] TOOL CALL\n{describe_tool(block.get('name'), block.get('input'))}")
        elif et == "user":
            content = ev.get("message", {}).get("content", [])
            if isinstance(content, list):
                for block in content:
                    if block.get("type") == "tool_result":
                        text = result_text(block.get("content", ""))
                        all_output.append(text)
                        err = bool(block.get("is_error"))
                        n_errors += err
                        label = "TOOL ERROR" if err else "TOOL RESULT"
                        name = tool_names.get(block.get("tool_use_id"), "")
                        if name in ("Read",) and not err:
                            entries.append(f"### [{ts}] {label} ({name})\n({len(text)} chars read)")
                        else:
                            entries.append(f"### [{ts}] {label}{f' ({name})' if name else ''}\n```\n{clip(text, MAX_OUTPUT)}\n```")
        elif et == "result":
            final = ev
            if ev.get("result"):
                entries.append(f"### [{ts}] FINAL MESSAGE\n{clip(str(ev.get('result')), MAX_TEXT)}")
        elif et == "unparsed":
            entries.append(f"### [{ts}] UNPARSED OUTPUT\n```\n{ev.get('raw')}\n```")

    # ---- exit reason ----
    # only look at Claude Code's own final status and stderr, never at the agent's command output
    tail_text = (json.dumps(final) if final else "") + stderr[-4000:]
    usage_limit = bool(re.search(r"usage limit|limit reached|rate.?limit", tail_text, re.I))
    if interrupted:
        exit_reason = "interrupted"
    elif container_rc == 124:
        exit_reason = "timeout"
    elif final and final.get("subtype") == "error_max_turns":
        exit_reason = "max_turns"
    elif usage_limit and not (final and final.get("subtype") == "success" and not final.get("is_error")):
        exit_reason = "usage_limit"
    elif not firewall_ok:
        exit_reason = "firewall_failed"
    elif final and final.get("subtype") == "success" and not final.get("is_error"):
        exit_reason = "finished"
    else:
        exit_reason = "error"

    # ---- output manifest ----
    manifest = []
    if os.path.isdir(code_dir):
        for root, dirs, files in os.walk(code_dir):
            dirs.sort()
            for name in sorted(files):
                p = os.path.join(root, name)
                rel = os.path.relpath(p, code_dir)
                manifest.append((rel, os.path.getsize(p), sha256(p)))
    with open(os.path.join(run_dir, "files_manifest.txt"), "w") as f:
        f.write("# sha256  size_bytes  path   (code/ at end of run)\n")
        for rel, size, h in manifest:
            f.write(f"{h}  {size:>10}  {rel}\n")

    # ---- results.json check ----
    results_check = {"present": False}
    rpath = os.path.join(code_dir, "results.json")
    if os.path.exists(rpath):
        results_check["present"] = True
        try:
            res = json.load(open(rpath))
            results_check["completed"] = res.get("completed")
            haystack = "\n".join(all_output)
            rows = []
            for r in res.get("results", []):
                v = r.get("ours")
                seen = isinstance(v, (int, float)) and any(s in haystack for s in number_variants(float(v)))
                rows.append({"setting": r.get("setting"), "metric": r.get("metric"),
                             "ours": v, "paper": r.get("paper"), "seen_in_command_output": seen})
            results_check["rows"] = rows
            results_check["unverified_values"] = sum(1 for r in rows if not r["seen_in_command_output"])
        except Exception as e:  # malformed results.json is itself a finding
            results_check["error"] = f"could not parse results.json: {e}"

    # ---- usage ----
    usage = (final or {}).get("usage", {}) or {}
    meta = dict(info)
    meta.update({
        "exit_reason": exit_reason,
        "container_exit_code": container_rc,
        "firewall_ok": firewall_ok,
        "num_turns": (final or {}).get("num_turns"),
        "tool_calls": n_tool_calls,
        "tool_errors": n_errors,
        "duration_s": round((final or {}).get("duration_ms", 0) / 1000) if final else None,
        "cost_usd": (final or {}).get("total_cost_usd"),
        "tokens": {k: usage.get(k) for k in ("input_tokens", "output_tokens",
                                             "cache_creation_input_tokens", "cache_read_input_tokens")},
        "output_files": len(manifest),
        "has_audit_log": os.path.exists(os.path.join(code_dir, "AUDIT_LOG.md")),
        "has_report": os.path.exists(os.path.join(code_dir, "REPORT.md")),
        "results": results_check,
    })
    with open(os.path.join(run_dir, "meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    # ---- audit.md ----
    lines = [
        f"# Audit log: {info.get('paper_id')} / {info.get('run_id')}",
        "",
        "Generated by the harness from the captured session record, outside the agent's container.",
        "The agent's own account of its work is in `code/AUDIT_LOG.md`; this file is the independent record.",
        "",
        "| | |", "|---|---|",
        f"| Run by | {info.get('run_by')} |",
        f"| Started / ended (UTC) | {info.get('start')} / {info.get('end')} |",
        f"| Model | {info.get('model')} |",
        f"| Prompt version (sha256) | `{info.get('prompt_sha256_16')}` |",
        f"| Image | `{str(info.get('image_id'))[:19]}` |",
        f"| Limits | {info.get('time_limit')}, {info.get('max_turns')} turns |",
        f"| **Exit reason** | **{exit_reason}** |",
        f"| Firewall check | {'passed' if firewall_ok else '**FAILED / missing**'} |",
        f"| Turns / tool calls / tool errors | {meta['num_turns']} / {n_tool_calls} / {n_errors} |",
        f"| Output files | {len(manifest)} (see `files_manifest.txt`) |",
        "",
        "## Results check",
        "",
    ]
    if not results_check["present"]:
        lines.append("No `results.json` was produced.")
    elif "error" in results_check:
        lines.append(results_check["error"])
    else:
        lines.append(f"`completed`: {results_check.get('completed')}")
        lines.append("")
        lines.append("| Setting | Metric | Ours | Paper | Value seen in command output? |")
        lines.append("|---|---|---|---|---|")
        for r in results_check["rows"]:
            mark = "yes" if r["seen_in_command_output"] else "**NO, check manually**"
            lines.append(f"| {r['setting']} | {r['metric']} | {r['ours']} | {r['paper']} | {mark} |")
        lines.append("")
        lines.append("A value not seen in any command output may still be legitimate (e.g. rounded, or only "
                     "written to a file), but it was not printed during the session and should be verified by rerunning.")
    lines += ["", "## Timeline", ""]
    for e in entries:
        lines += [e, ""]
    with open(os.path.join(run_dir, "audit.md"), "w") as f:
        f.write("\n".join(lines) + "\n")

    print(f"audit: exit_reason={exit_reason} turns={meta['num_turns']} files={len(manifest)} "
          f"results={'yes' if results_check['present'] else 'no'}")


if __name__ == "__main__":
    main()

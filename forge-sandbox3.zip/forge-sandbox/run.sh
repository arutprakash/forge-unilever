#!/bin/bash
# Run one Forge benchmark paper: the agent reads the paper, implements it, runs it on the
# provided dataset and reports results, inside a fresh, network-locked container.
#
# Usage: ./run.sh <paper_id>
#   expects inputs/<paper_id>/ to contain the paper (PDF) and its dataset, and nothing else
#   writes results/<paper_id>/<run_id>/
set -euo pipefail

PAPER_ID="${1:?usage: ./run.sh <paper_id>}"
IMAGE="${FORGE_IMAGE:-forge-sandbox:latest}"   # set to the shared image@sha256:... once pushed
TIME_LIMIT="${FORGE_TIME_LIMIT:-2h}"           # e.g. 30m, 2h
MAX_TURNS="${FORGE_MAX_TURNS:-200}"            # hard cap on agent steps
MODEL="${FORGE_MODEL:-}"                       # e.g. claude-sonnet-5-5; empty = Claude Code default

if [ -z "${CLAUDE_CODE_OAUTH_TOKEN:-}" ] && [ -z "${ANTHROPIC_API_KEY:-}" ]; then
  echo "set CLAUDE_CODE_OAUTH_TOKEN (subscription, from 'claude setup-token') or ANTHROPIC_API_KEY" >&2; exit 1
fi
AUTH_MODE=$([ -n "${CLAUDE_CODE_OAUTH_TOKEN:-}" ] && echo subscription || echo api_key)

ROOT="$(cd "$(dirname "$0")" && pwd)"
INPUT_DIR="$ROOT/inputs/$PAPER_ID"
[ -d "$INPUT_DIR" ] || { echo "no such input folder: $INPUT_DIR" >&2; exit 1; }
command -v perl >/dev/null || { echo "perl is required (preinstalled on macOS and most Linux)" >&2; exit 1; }

now() { date -u +%Y-%m-%dT%H:%M:%SZ; }
hash16() { if command -v sha256sum >/dev/null; then sha256sum "$1"; else shasum -a 256 "$1"; fi | cut -c1-16; }
human_time() {  # 30m -> 30 minutes, 2h -> 2 hours
  local n="${1%[smhd]}"
  case "$1" in *s) echo "$n seconds";; *m) echo "$n minutes";; *h) echo "$n hours";; *d) echo "$n days";; *) echo "$1 seconds";; esac
}

RUN_ID="$(date +%Y%m%d-%H%M%S)-$(whoami)"
OUT_DIR="$ROOT/results/$PAPER_ID/$RUN_ID"
mkdir -p "$OUT_DIR/code"
chmod 777 "$OUT_DIR/code"   # container's 'agent' user needs to write here

# Fill the budget into the prompt and keep the exact text used for this run.
sed -e "s/{{TIME_LIMIT}}/$(human_time "$TIME_LIMIT")/g" -e "s/{{MAX_TURNS}}/$MAX_TURNS/g" \
  "$ROOT/prompt.md" > "$OUT_DIR/prompt_used.md"

IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$IMAGE")"
MODEL_ARGS=""
[ -n "$MODEL" ] && MODEL_ARGS="--model $MODEL"
CONTAINER="forge-${RUN_ID}"
INTERRUPTED=0

# Ctrl+C: stop the container (docker ignores the signal otherwise), then still write the audit record.
on_interrupt() {
  INTERRUPTED=1
  echo; echo "Interrupted, stopping container (audit record will still be written) ..." >&2
  docker stop -t 5 "$CONTAINER" >/dev/null 2>&1 || true
}
trap on_interrupt INT TERM

START="$(now)"
echo "Running $PAPER_ID as $RUN_ID (limit $TIME_LIMIT, $MAX_TURNS turns) ..."
set +e
(
  set -o pipefail
  docker run --rm --name "$CONTAINER" \
    --cap-add NET_ADMIN --cap-add NET_RAW \
    --cpus 4 --memory 16g \
    -e ANTHROPIC_API_KEY -e CLAUDE_CODE_OAUTH_TOKEN -e PYTHONUNBUFFERED=1 \
    -v "$INPUT_DIR:/workspace/input:ro" \
    -v "$OUT_DIR/prompt_used.md:/workspace/prompt.md:ro" \
    -v "$OUT_DIR/code:/workspace/code" \
    -w /workspace/code \
    "$IMAGE" \
    bash -c "timeout $TIME_LIMIT claude -p \"\$(cat /workspace/prompt.md)\" \
              --dangerously-skip-permissions \
              --disallowedTools WebSearch WebFetch \
              --add-dir /workspace/input \
              --max-turns $MAX_TURNS \
              --output-format stream-json --verbose $MODEL_ARGS" \
    2> "$OUT_DIR/stderr.log" \
  | perl -MPOSIX -MJSON::PP -ne '
      BEGIN { $| = 1; $SIG{INT} = "IGNORE"; }
      chomp; next unless length;
      my $ts = strftime("%Y-%m-%dT%H:%M:%SZ", gmtime);
      my $ev = /^\s*\{/ ? $_ : encode_json({type => "raw", raw => $_});
      print "{\"ts\":\"$ts\",\"event\":$ev}\n";' \
  > "$OUT_DIR/transcript.jsonl"
) &
PIPE_PID=$!
wait $PIPE_PID
RC=$?
# wait returns early when Ctrl+C arrives; wait again until the pipeline has really finished
while kill -0 $PIPE_PID 2>/dev/null; do wait $PIPE_PID; RC=$?; done
set -e
trap - INT TERM
END="$(now)"

cat > "$OUT_DIR/run_info.json" <<EOF
{
  "paper_id": "$PAPER_ID",
  "run_id": "$RUN_ID",
  "run_by": "$(whoami)",
  "model": "${MODEL:-default}",
  "auth_mode": "$AUTH_MODE",
  "image_id": "$IMAGE_ID",
  "prompt_sha256_16": "$(hash16 "$ROOT/prompt.md")",
  "time_limit": "$TIME_LIMIT",
  "max_turns": $MAX_TURNS,
  "start": "$START",
  "end": "$END"
}
EOF

# Build audit.md, files_manifest.txt and meta.json in a separate container with no network.
docker run --rm --network none --entrypoint python3 \
  --user "$(id -u):$(id -g)" \
  -v "$OUT_DIR:/audit" -v "$ROOT/tools:/tools:ro" \
  "$IMAGE" /tools/make_audit.py /audit "$RC" "$INTERRUPTED" /audit/run_info.json \
  || echo "WARNING: could not build audit record; transcript.jsonl is still complete" >&2
rm -f "$OUT_DIR/run_info.json"

echo "Done -> $OUT_DIR"

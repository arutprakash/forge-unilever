# Forge sandbox

Runs Claude Code on one paper at a time. The agent reads the paper, implements it, runs it on the provided dataset and reports results, inside a Docker container that can reach the Anthropic API and nothing else (no GitHub, no web search). Every run leaves a full audit record.

## Files

| File | What it is |
|---|---|
| `prompt.md` | The one prompt used for every paper. `{{TIME_LIMIT}}` and `{{MAX_TURNS}}` are filled in automatically |
| `run.sh` | Runs one paper and writes its results folder |
| `tools/make_audit.py` | Builds the audit record after each run (runs with no network, outside the agent's container) |
| `Dockerfile` | Image: Claude Code + Python ML stack |
| `init-firewall.sh` | Default-deny outbound firewall, allows only `api.anthropic.com` |
| `entrypoint.sh` | Applies firewall as root, then runs the agent as an unprivileged user |
| `settings.json` | Claude Code permissions: denies WebSearch / WebFetch |
| `papers.csv` | Paper list and assignments |

## One-time setup (each teammate)

1. Install Docker Desktop (Mac/Windows) or Docker Engine (Linux).
2. Authenticate, one of:
   - **Your own Claude Pro/Max subscription:** install Claude Code on your laptop, run `claude setup-token`, then
     `echo 'export CLAUDE_CODE_OAUTH_TOKEN=<token>' >> ~/.zshrc && source ~/.zshrc` (never commit or share it)
   - **API key** from https://console.anthropic.com: `export ANTHROPIC_API_KEY=sk-ant-...`
3. Build the image (same pinned version for everyone):
   `docker build -t forge-sandbox --build-arg CLAUDE_CODE_VERSION=2.1.301 .`
4. `chmod +x run.sh`
5. Check the firewall (free, uses no Claude usage):
   `docker run --rm --cap-add NET_ADMIN --cap-add NET_RAW forge-sandbox curl -s --max-time 5 https://github.com && echo "REACHABLE - bad" || echo "BLOCKED - good"`

## Running a paper

1. Claim a row in `papers.csv` (set `assignee`, `status=in_progress`).
2. Put the paper and its dataset in `inputs/<paper_id>/`, e.g. `inputs/patchtst/paper.pdf` and `inputs/patchtst/ETTh1.csv`. Nothing else: no code, no repo.
3. Run: `./run.sh <paper_id>`
   Common settings: `FORGE_MODEL=claude-sonnet-5-5 FORGE_TIME_LIMIT=1h FORGE_MAX_TURNS=150 ./run.sh <paper_id>`
4. Ctrl+C stops the run cleanly; the audit record is still written.
5. Set `status=done` and upload the run folder to the shared drive.

Settings (environment variables):
- `FORGE_TIME_LIMIT`: wall-clock limit, e.g. `30m`, `2h` (default `2h`)
- `FORGE_MAX_TURNS`: max agent steps (default `200`)
- `FORGE_MODEL`: pin a model (default: Claude Code's default)
- `FORGE_IMAGE`: use a shared image instead of the local build

## What a run produces: `results/<paper_id>/<run_id>/`

| File | Written by | Contents |
|---|---|---|
| `code/` | agent | Implementation, `run.sh`, `results.json`, `REPORT.md`, `AUDIT_LOG.md` |
| `code/AUDIT_LOG.md` | agent | Its own log of decisions, ambiguities, deviations, runs and errors |
| `audit.md` | harness | Independent, timestamped record of every agent message, command, file write and output, plus the results check |
| `transcript.jsonl` | harness | The raw, complete session record (timestamped), source for `audit.md` |
| `files_manifest.txt` | harness | sha256 and size of every output file at the end of the run |
| `meta.json` | harness | Who/when/model/prompt version/image, exit reason, turns, tokens, cost, results check |
| `prompt_used.md` | harness | The exact prompt text this run received |
| `stderr.log` | harness | Container log; must contain `firewall: OK` |

Exit reasons in `meta.json`: `finished`, `timeout`, `max_turns`, `usage_limit` (rerun later, don't count as a failure), `interrupted`, `firewall_failed`, `error`.

**Results check:** for each value in `results.json`, `audit.md` says whether that number appeared in any command output during the session. A value marked "NO" was never printed and must be verified by rerunning `code/run.sh` yourself.

## Rules

- Never edit `prompt.md`, the image, or the Claude Code version mid-benchmark. If you must, bump a version and rerun. (The prompt hash in `meta.json` shows which version each run used.)
- Keep the same model and limits for every paper in a comparison.
- Grading against `reference_repo_url` happens afterwards, outside the container, ideally by a different teammate.
- Log any manual intervention (restart, fixed PDF) in a deviations note.

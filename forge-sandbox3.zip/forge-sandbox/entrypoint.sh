#!/bin/bash
# Set up the firewall as root, then run the given command as the unprivileged 'agent' user.
set -euo pipefail
/usr/local/bin/init-firewall.sh
exec runuser -u agent -- env HOME=/home/agent PATH="$PATH" ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-}" CLAUDE_CODE_OAUTH_TOKEN="${CLAUDE_CODE_OAUTH_TOKEN:-}" "$@"

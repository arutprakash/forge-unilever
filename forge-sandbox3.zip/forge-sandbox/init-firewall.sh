#!/bin/bash
# Default-deny outbound firewall. Only the Anthropic API (and DNS to resolve it) is reachable.
# Runs as root at container start, before dropping to the unprivileged 'agent' user.
set -euo pipefail

ALLOWED_DOMAINS=(
  api.anthropic.com
)

ipset create allowed hash:ip -exist
for domain in "${ALLOWED_DOMAINS[@]}"; do
  ips=$(dig +short A "$domain" | grep -E '^[0-9.]+$' || true)
  if [ -z "$ips" ]; then
    echo "firewall: could not resolve $domain" >&2
    exit 1
  fi
  for ip in $ips; do ipset add allowed "$ip" -exist; done
done

iptables -F OUTPUT
iptables -P OUTPUT DROP
iptables -A OUTPUT -o lo -j ACCEPT
iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -p udp --dport 53 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -j ACCEPT
iptables -A OUTPUT -p tcp --dport 443 -m set --match-set allowed dst -j ACCEPT
# Log anything else that tries to leave, then it hits the DROP policy.
iptables -A OUTPUT -j LOG --log-prefix "FORGE-BLOCKED: " --log-level 4

# Block IPv6 entirely.
ip6tables -P OUTPUT DROP 2>/dev/null || true

# Self-check: the API must work, GitHub must not.
if curl -s --max-time 5 https://github.com >/dev/null 2>&1; then
  echo "firewall: FAILED - github.com is reachable" >&2
  exit 1
fi
if ! curl -s --max-time 10 -o /dev/null https://api.anthropic.com; then
  echo "firewall: FAILED - api.anthropic.com is not reachable" >&2
  exit 1
fi
echo "firewall: OK (github blocked, anthropic api reachable)" >&2
